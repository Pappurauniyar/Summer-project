<ul>
	<li><a href="login.php">SIGN IN</a></li>
	<li><p>|</p></li>
	<li><a href="register.php">REGISTER</a></li>
</ul>
