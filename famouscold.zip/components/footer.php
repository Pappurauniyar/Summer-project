<footer>
    <nav id="bottom-nav">
        <ul>
            <li class="text-link"><a href="admin/gateway.php">ADMIN</a></li>
            <li><a href="https://www.facebook.com/https://www.facebook.com/profile.php?id=100081635318038&mibextid=JRoKGi" target="_blank"><img src="images/social/facebook.png" alt="Facebook"/></a></li>
            <li><a href="https://twitter.com/your-twitter-handle" target="_blank"><img src="images/social/twitter.png" alt="Twitter"/></a></li>
            <li><a href="https://www.instagram.com/pappu.rauniyar" target="_blank"><img src="images/social/instagram.png" alt="Instagram"/></a></li>
            <li><a href="https://www.pappurauniyar.com.np/home"  target="_blank"><img src="images/social/rss.png" alt="RSS"/></a></li>
            <li><a href="https://www.pinterest.com/your-pinterest-url" target="_blank"><img src="images/social/pinterest.png" alt="Pinterest"/></a></li>
        </ul>
    </nav>
</footer>
