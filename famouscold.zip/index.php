<?php
	include "resources/initiate.php";
	$title = "Famous Cold Store";
	$style = "styles/home.css";
	include "components/header.php";
?>

			<div class="banner">
			<style>
        #banner-text {
            font-size: 35px; /* You can adjust the size to your preference, for example, 20px */
			color: white;
			
        }

		
			
		
		</style>
				<img src="images/banner.jpg" alt="Bar" class="banner-image">
				<img src="images/logo1.png" alt="Famous Cold Store" id="banner-logo">
				
				<p id="banner-text"> <br /> Where Wine <br/>Enthusiast  <br /> Gather<br /></p>
				
			</div>
			
			<h1>Latest Products</h1>
<?php
	//RETRIEVES 4 RECENT PRODUCTS FROM DIFFERENT CATEGORIES
	$sql = "SELECT * FROM product WHERE created IN (select MAX(created) FROM product GROUP BY drink) LIMIT 4";
	$page=mysqli_query($db, $sql);
	while ($row=mysqli_fetch_assoc($page)) { 
		echo product_thumb($row);
	}


?>

<?php include "components/footer.php"; ?>